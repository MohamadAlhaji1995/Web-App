import React from 'react';
import ReparaturAnfrageForm from '../components/ReparaturAnfrageForm';

const ReparaturAnfragePage = () => {
  return (
    <div>
      <ReparaturAnfrageForm />
    </div>
  );
};

export default ReparaturAnfragePage;
